export {};
// // type for Viewport Helper function option
// export type ViewportHelperFunctionOptions = {
// 	duration?: number;
// };
// // type for zoom in and
// export type ZoomInOut = (options?: ViewportHelperFunctionOptions) => void;
